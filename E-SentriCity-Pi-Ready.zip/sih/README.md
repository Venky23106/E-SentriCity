# AURA incident dashboard and edge vision

## Raspberry Pi setup

Use Raspberry Pi OS 64-bit (aarch64). Copy this `sih` folder to the Pi and connect the Pi and ESP32-CAM to the same network. From the `sih` folder, run the one-time setup:

```bash
bash BACKEND/setup_pi.sh
```

The setup installs OS libraries, creates `.venv`, installs Python dependencies, loads the bundled YOLO model, and runs one CPU inference smoke check. It needs internet access and free disk space; the first install can take several minutes.

Configure and launch:

```bash
nano BACKEND/.env
# Set AURA_VIDEO_SOURCE to the ESP32-CAM stream URL shown by its firmware.
bash BACKEND/check_pi_camera.sh
bash BACKEND/run_pi.sh
```

Leave `AURA_VIDEO_SOURCE` blank to use the bundled demo video first. The terminal prints the Pi LAN address. Open `http://<PI-IP>:5000/` on a computer on the same network.

## Connect the real audio detector

The worker stays connected and waits for triggers. The included `ai.py` currently has simulated sensor readings. The real audio model should POST to `http://127.0.0.1:5000/api/trigger` on the Pi with JSON such as:

```json
{"node_id":"POLE-01","trigger_source":"audio","anomaly_type":"VEHICULAR_CRASH_ACCIDENT"}
```

The gateway forwards the trigger to the vision worker, which samples the configured stream and reports measured results. Two or more vehicle detections are only a potential incident requiring operator review; this COCO object detector does not prove a collision. Sensor values appear only if supplied by the audio device. Keep this unauthenticated demo API on a trusted LAN.

## CPU and hardware notes

Inference runs on CPU with a 320-pixel input, 1 sampled frame per second, and at most 2 threads by default. It filters inference to person and vehicle classes to cut CPU work. If the Pi is overloaded, set `AURA_INFERENCE_FPS=0.5` in `BACKEND/.env`. The setup requires aarch64 because the vision worker uses PyTorch/Ultralytics. The camera check confirms that OpenCV can read one frame before starting the dashboard worker.

To exercise the same audio-to-vision path before connecting the ESP32-CAM, leave the video source blank and click **Test Audio → Vision Trigger** in the dashboard.
