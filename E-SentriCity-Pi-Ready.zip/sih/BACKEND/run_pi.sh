#!/usr/bin/env bash
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$BACKEND_DIR")"
cd "$BACKEND_DIR"
if [[ -f "$BACKEND_DIR/.env" ]]; then
  set -a
  source "$BACKEND_DIR/.env"
  set +a
fi

if [[ ! -x "$PROJECT_DIR/.venv/bin/python" ]]; then
  echo "Pi environment is not installed. Run: bash $BACKEND_DIR/setup_pi.sh" >&2
  exit 2
fi
PY="$PROJECT_DIR/.venv/bin/python"

export AURA_VIDEO_SOURCE="${AURA_VIDEO_SOURCE:-$BACKEND_DIR/crash.mp4}"
export AURA_MODEL_PATH="${AURA_MODEL_PATH:-$PROJECT_DIR/yolov8n.pt}"
export AURA_GATEWAY_URL="${AURA_GATEWAY_URL:-http://127.0.0.1:5000}"
export AURA_GATEWAY_WS="${AURA_GATEWAY_WS:-ws://127.0.0.1:5000/ws/edge}"
export AURA_HOST="${AURA_HOST:-0.0.0.0}"
export AURA_PORT="${AURA_PORT:-5000}"

"$PY" "$BACKEND_DIR/server.py" &
GATEWAY_PID=$!
cleanup() {
  kill "$GATEWAY_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

ready=0
for _ in $(seq 1 40); do
  if curl -fsS "$AURA_GATEWAY_URL/health" >/dev/null; then ready=1; break; fi
  sleep 0.5
done
if [[ "$ready" != 1 ]]; then
  echo "Gateway did not become ready; check port $AURA_PORT and BACKEND/server.py logs." >&2
  exit 1
fi

echo "AURA dashboard: $AURA_GATEWAY_URL/"
echo "Video source: $AURA_VIDEO_SOURCE"
echo "LAN access: http://$(hostname -I 2>/dev/null | awk '{print $1}'):$AURA_PORT/"
echo "Waiting for audio triggers; Ctrl+C stops the gateway and vision worker."
"$PY" "$BACKEND_DIR/cctv_edge_node.py"

