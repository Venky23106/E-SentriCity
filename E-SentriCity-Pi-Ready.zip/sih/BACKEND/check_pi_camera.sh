#!/usr/bin/env bash
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$BACKEND_DIR")"
if [[ ! -x "$PROJECT_DIR/.venv/bin/python" ]]; then
  echo "Run setup first: bash $BACKEND_DIR/setup_pi.sh" >&2
  exit 2
fi
if [[ -f "$BACKEND_DIR/.env" ]]; then
  set -a
  source "$BACKEND_DIR/.env"
  set +a
fi
export AURA_VIDEO_SOURCE="${AURA_VIDEO_SOURCE:-$BACKEND_DIR/crash.mp4}"
exec "$PROJECT_DIR/.venv/bin/python" - <<'PY'
import os
import cv2

source = os.environ["AURA_VIDEO_SOURCE"]
if source.isdecimal():
    source = int(source)
print(f"Checking video source: {source}")
capture = cv2.VideoCapture(source)
capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
try:
    if not capture.isOpened():
        raise SystemExit("FAIL: OpenCV cannot open this source. Check the ESP32 IP, stream path, and shared Wi-Fi/LAN.")
    ok, frame = capture.read()
    if not ok or frame is None:
        raise SystemExit("FAIL: stream opened but returned no frame. Check ESP32 streaming mode and URL.")
    height, width = frame.shape[:2]
    fps = capture.get(cv2.CAP_PROP_FPS)
    print(f"OK: received {width}x{height} frame; reported FPS={fps:.1f}")
finally:
    capture.release()
PY
