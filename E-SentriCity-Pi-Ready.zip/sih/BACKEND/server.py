#!/usr/bin/env python3
"""AURA gateway: audio trigger -> edge vision worker -> live dashboard."""

import json
import os
import time
import uuid
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

HERE = Path(__file__).resolve().parent
PROJECT_DIR = HERE.parent
DASHBOARD = PROJECT_DIR / "final.html"

app = FastAPI(title="AURA Control Tower", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ConnectionManager:
    def __init__(self) -> None:
        self.dashboard_connections: set[WebSocket] = set()
        self.edge_connections: set[WebSocket] = set()

    async def broadcast(self, connections: set[WebSocket], message: dict[str, Any]) -> None:
        stale: list[WebSocket] = []
        for connection in tuple(connections):
            try:
                await connection.send_json(message)
            except Exception:
                stale.append(connection)
        for connection in stale:
            connections.discard(connection)

    async def broadcast_to_dashboards(self, message: dict[str, Any]) -> None:
        await self.broadcast(self.dashboard_connections, message)

    async def send_to_edge_workers(self, message: dict[str, Any]) -> int:
        workers = tuple(self.edge_connections)
        await self.broadcast(self.edge_connections, message)
        return len(workers)


manager = ConnectionManager()


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "service": "aura-gateway",
        "dashboard_clients": len(manager.dashboard_connections),
        "vision_workers": len(manager.edge_connections),
    }


@app.get("/")
async def dashboard() -> FileResponse:
    return FileResponse(DASHBOARD)


if (HERE / "crash.mp4").is_file():
    app.mount("/BACKEND", StaticFiles(directory=str(HERE)), name="backend-assets")


@app.post("/api/trigger")
async def trigger_visual_check(payload: dict[str, Any]) -> dict[str, Any]:
    """Called by the audio node after its own detection passes its threshold."""
    trigger = {
        **payload,
        "node_id": str(payload.get("node_id") or "POLE-01"),
        "trigger_id": str(payload.get("trigger_id") or uuid.uuid4()),
        "timestamp_ms": int(payload.get("timestamp_ms") or time.time() * 1000),
        "trigger_source": str(payload.get("trigger_source") or "audio"),
    }
    workers = await manager.send_to_edge_workers({"type": "VISION_TRIGGER", "data": trigger})
    await manager.broadcast_to_dashboards({"type": "AUDIO_TRIGGER", "data": trigger})
    print(f"[TRIGGER] {trigger['node_id']} ({trigger['trigger_source']}); workers={workers}")
    return {"status": "accepted", "trigger_id": trigger["trigger_id"], "vision_workers": workers}


@app.post("/api/telemetry")
async def ingest_cctv_telemetry(payload: dict[str, Any]) -> dict[str, Any]:
    event_type = str(payload.get("type") or "EDGE_ALERT")
    if event_type not in {"EDGE_ALERT", "VISION_RESULT"}:
        event_type = "EDGE_ALERT"
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    await manager.broadcast_to_dashboards({"type": event_type, "data": data})
    print(f"[VISION] {data.get('visual_status', data.get('anomaly_type', event_type))} from {data.get('node_id', 'unknown')}")
    return {"status": "accepted", "type": event_type}


@app.websocket("/ws/dashboard")
async def websocket_dashboard(websocket: WebSocket) -> None:
    await websocket.accept()
    manager.dashboard_connections.add(websocket)
    print("[SERVER] Dashboard connected")
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        manager.dashboard_connections.discard(websocket)
        print("[SERVER] Dashboard disconnected")


@app.websocket("/ws/edge")
async def websocket_edge(websocket: WebSocket) -> None:
    """Bidirectional channel: gateway sends audio triggers; Pi worker returns vision results."""
    await websocket.accept()
    manager.edge_connections.add(websocket)
    await websocket.send_json({"type": "WORKER_READY"})
    print("[SERVER] Vision worker connected")
    try:
        while True:
            message = json.loads(await websocket.receive_text())
            if not isinstance(message, dict):
                continue
            message_type = message.get("type")
            if message_type in {"EDGE_ALERT", "VISION_RESULT"}:
                data = message.get("data") if isinstance(message.get("data"), dict) else message
                await manager.broadcast_to_dashboards({"type": message_type, "data": data})
                print(f"[VISION] {data.get('visual_status', data.get('anomaly_type', message_type))} from {data.get('node_id', 'unknown')}")
    except WebSocketDisconnect:
        pass
    except (json.JSONDecodeError, ValueError) as exc:
        print(f"[EDGE WS] Invalid worker message: {exc}")
    finally:
        manager.edge_connections.discard(websocket)
        print("[SERVER] Vision worker disconnected")


if __name__ == "__main__":
    uvicorn.run(app, host=os.getenv("AURA_HOST", "0.0.0.0"), port=int(os.getenv("AURA_PORT", "5000")))
