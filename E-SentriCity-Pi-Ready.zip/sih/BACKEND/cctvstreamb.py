import cv2
from detector import EdgeAIVisionDetector

class CCTVManager:
    def __init__(self, cctv_source):
        # cctv_source can be a video file ("accident.mp4") or RTSP URL
        self.cap = cv2.VideoCapture(cctv_source)
        self.detector = EdgeAIVisionDetector()

    def process_live_feed(self):
        while self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                break
            
            # Analyze frame for anomalies
            metrics = self.detector.analyze_frame(frame)
            
            if metrics.get("accident_detected"):
                print("🚨 CRASH DETECTED ON CCTV! Dispatching Alert...")
                # Trigger WebSocket dispatch payload here

        self.cap.release()

if __name__ == "__main__":
    # Test using your accident video clip file!
    manager = CCTVManager("accident_footage.mp4")
    manager.process_live_feed()