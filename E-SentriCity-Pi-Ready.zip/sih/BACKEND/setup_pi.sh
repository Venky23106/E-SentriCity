#!/usr/bin/env bash
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$BACKEND_DIR")"

if [[ "$(uname -m)" != "aarch64" ]]; then
  echo "Use Raspberry Pi OS 64-bit (aarch64). Detected: $(uname -m)" >&2
  exit 2
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo "This setup script expects Raspberry Pi OS / Debian with apt." >&2
  exit 2
fi

echo "Installing Raspberry Pi OS runtime libraries..."
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip python3-dev curl libgl1 libglib2.0-0 libgomp1

FREE_MB="$(df -Pm "$PROJECT_DIR" | awk 'NR==2 {print $4}')"
if [[ "$FREE_MB" -lt 1500 ]]; then
  echo "Warning: only ${FREE_MB} MB free. PyTorch/Ultralytics setup may need more than 1.5 GB." >&2
fi

PYTHON="$(command -v python3)"
PY_MINOR="$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
case "$PY_MINOR" in
  3.10|3.11|3.12|3.13) ;;
  *) echo "Python 3.10–3.13 is required; found $PY_MINOR. Use 64-bit Raspberry Pi OS." >&2; exit 2 ;;
esac

if [[ ! -f "$PROJECT_DIR/yolov8n.pt" ]]; then
  echo "Missing bundled model: $PROJECT_DIR/yolov8n.pt" >&2
  exit 2
fi

echo "Creating isolated Python environment (first install can take several minutes)..."
if [[ ! -x "$PROJECT_DIR/.venv/bin/python" ]]; then
  "$PYTHON" -m venv "$PROJECT_DIR/.venv"
fi
PY="$PROJECT_DIR/.venv/bin/python"
"$PY" -m pip install --no-cache-dir --upgrade pip
"$PY" -m pip install --no-cache-dir -r "$BACKEND_DIR/requirements.txt"

echo "Checking the installed runtime and bundled model..."
AURA_MODEL_PATH="$PROJECT_DIR/yolov8n.pt" "$PY" - <<'PY'
import cv2, torch, ultralytics, os
import numpy as np
from ultralytics import YOLO
print(f"Python runtime ready | OpenCV {cv2.__version__} | PyTorch {torch.__version__} | Ultralytics {ultralytics.__version__}")
model = YOLO(os.environ["AURA_MODEL_PATH"])
print(f"Model loaded: {len(model.names)} COCO classes")
model.predict(np.zeros((320, 320, 3), dtype=np.uint8), imgsz=320,
              classes=[0, 2, 3, 5, 7], max_det=20, device="cpu", verbose=False)
print("CPU inference smoke check passed")
PY

if [[ ! -f "$BACKEND_DIR/.env" ]]; then
  cp "$BACKEND_DIR/.env.example" "$BACKEND_DIR/.env"
  echo "Created BACKEND/.env. Edit AURA_VIDEO_SOURCE to your ESP32-CAM stream URL before starting."
fi
echo "Setup complete. Start with: cd '$BACKEND_DIR' && bash run_pi.sh"
