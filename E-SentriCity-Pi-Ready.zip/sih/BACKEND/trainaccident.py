from ultralytics import YOLO

# Load base nano model
model = YOLO("yolov8n.pt")

# Train on custom accident dataset (runs fast and light)
model.train(
    data="accident_dataset.yaml", 
    epochs=15, 
    imgsz=320,  # Keep resolution lower for ultra-fast edge inference
    batch=8
)

# Saved weight will be 'runs/detect/train/weights/best.pt'