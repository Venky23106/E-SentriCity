#!/usr/bin/env python3
"""
AURA Edge AI Engine for Real Hardware
Features: Low-Power Sensor Sampling, Weighted Sensor Fusion Math,
Inference Triggering, and Automatic Telemetry Payload Dispatch.
"""

import time
import json
import math
import os
import random
import threading
import requests  # Send HTTP POST alerts to Control Room

# ==========================================
# 1. HARDWARE & THRESHOLD CONFIGURATION
# ==========================================
NODE_ID = "EDGE-NODE-A1"
GATEWAY_URL = os.getenv("AURA_GATEWAY_URL", "http://127.0.0.1:5000")
STREAM_PORT = 8080

# Fusion Math Weights (Must sum to 1.0)
WEIGHT_ACOUSTIC = 0.45
WEIGHT_IMPACT = 0.35
WEIGHT_RADAR = 0.20

FUSION_WAKE_THRESHOLD = 0.65  # Score required to wake camera & AI

# Baseline Environmental Benchmarks
AMBIENT_DB_BASE = 40.0        # Normal ambient sound (dB)
MAX_DB_LIMIT = 120.0          # Distress scream / explosion threshold
GRAVITY_G_BASE = 1.0          # Normal Earth gravity
MAX_G_LIMIT = 5.0             # Severe crash / g-force limit


# ==========================================
# 2. HARDWARE SENSOR INTERFACE CLASS
# ==========================================
class SensorHardwareInterface:
    """Handles direct physical hardware reads (I2C, I2S, GPIO)."""
    def __init__(self):
        self.acoustic_db = AMBIENT_DB_BASE
        self.g_force = GRAVITY_G_BASE
        self.radar_active = False

    def read_sensors(self):
        """
        Replace these mocked readings with physical hardware libraries:
        - Acoustic: INMP441 via alsaaudio / PyAudio
        - Accelerometer: MPU6050 via smbus2 / mpu6050-raspberrypi
        - Radar: RCWL-0516 via RPi.GPIO
        """
        # --- PHYSICAL HARDWARE INTEGRATION HOOKS ---
        # self.acoustic_db = read_i2s_microphone_db()
        # self.g_force = read_mpu6050_accel_g()
        # self.radar_active = GPIO.input(RADAR_PIN)
        
        # Simulated jitter for VSCode testing:
        self.acoustic_db = max(35.0, self.acoustic_db + random.uniform(-1.5, 1.5))
        self.g_force = max(0.9, self.g_force + random.uniform(-0.05, 0.05))
        return self.acoustic_db, self.g_force, self.radar_active

    def trigger_simulated_event(self, event_type: str):
        """Helper to inject real hardware anomaly triggers inside VSCode."""
        if event_type == "CRASH":
            self.g_force = 4.2
            self.acoustic_db = 92.0
            self.radar_active = True
        elif event_type == "KIDNAPPING_SCREAM":
            self.acoustic_db = 105.0
            self.radar_active = True
            self.g_force = 1.8


# ==========================================
# 3. EDGE AI FUSION & DISPATCH ENGINE
# ==========================================
class EdgeAIFusionEngine:
    def __init__(self):
        self.hardware = SensorHardwareInterface()
        self.is_camera_active = False
        self.running = True

    def calculate_fusion_score(self, db: float, g_force: float, radar: bool) -> float:
        """Applies mathematical normalization and weighted fusion calculation."""
        # Normalize inputs between 0.0 and 1.0
        norm_acoustic = min(max((db - AMBIENT_DB_BASE) / (MAX_DB_LIMIT - AMBIENT_DB_BASE), 0.0), 1.0)
        norm_impact = min(max((g_force - GRAVITY_G_BASE) / (MAX_G_LIMIT - GRAVITY_G_BASE), 0.0), 1.0)
        norm_radar = 1.0 if radar else 0.0

        # Fusion Equation: S_f = (w_a * A) + (w_v * V) + (w_r * R)
        score = (
            (norm_acoustic * WEIGHT_ACOUSTIC) +
            (norm_impact * WEIGHT_IMPACT) +
            (norm_radar * WEIGHT_RADAR)
        )
        return round(score, 3)

    def classify_anomaly(self, db: float, g_force: float, score: float) -> str:
        """Classifies incident threat state based on fused sensor heuristics."""
        if g_force >= 3.0:
            return "VEHICULAR_CRASH_ACCIDENT"
        elif db >= 95.0:
            return "DISTRESS_SCREAM_KIDNAPPING_ALERT"
        elif score >= FUSION_WAKE_THRESHOLD:
            return "UNAUTHORIZED_SUSPICIOUS_ACTIVITY"
        return "NOMINAL"

    def dispatch_payload(self, fusion_score: float, anomaly_type: str, db: float, g_force: float, radar: bool):
        """Formats standard JSON payload and transmits to Control Room Gateway."""
        payload = {
            "node_id": NODE_ID,
            "timestamp_ms": int(time.time() * 1000),
            "state": "ACTIVE_ALERT",
            "fusion_score": fusion_score,
            "anomaly_type": anomaly_type,
            "sensors": {
                "decibel_peak": round(db, 1),
                "g_force": round(g_force, 2),
                "radar_motion": radar
            },
        }

        print(f"\n🚨 [CRITICAL ALERT] Transmitting Payload to Control Room:\n{json.dumps(payload, indent=2)}")

        # The acoustic node asks the gateway to wake its connected vision worker.
        try:
            response = requests.post(f"{GATEWAY_URL}/api/trigger", json={
                **payload,
                "trigger_source": "audio_sensor",
            }, timeout=2.0)
            response.raise_for_status()
            print(f"[GATEWAY] Vision trigger accepted: {response.json()}")
        except Exception as e:
            print(f"[Network Warning] Unable to reach control room server: {e}")

    def run(self):
        """Main Edge Loop (Sampling at 10 Hz / 100ms interval)."""
        print(f"==================================================")
        print(f" AURA Edge AI Engine Running on {NODE_ID}")
        print(f" Wake Threshold: {FUSION_WAKE_THRESHOLD} | Loop Rate: 10Hz")
        print(f"==================================================")

        while self.running:
            db, g_force, radar = self.hardware.read_sensors()
            fusion_score = self.calculate_fusion_score(db, g_force, radar)

            if fusion_score >= FUSION_WAKE_THRESHOLD:
                if not self.is_camera_active:
                    print(f"\n[POWER RELAY] Wake Signal Sent -> Camera & Edge AI Models Powered ON!")
                    self.is_camera_active = True

                anomaly_type = self.classify_anomaly(db, g_force, fusion_score)
                self.dispatch_payload(fusion_score, anomaly_type, db, g_force, radar)
                
                # Settle down hardware values post-trigger
                self.hardware.acoustic_db = AMBIENT_DB_BASE
                self.hardware.g_force = GRAVITY_G_BASE
                self.hardware.radar_active = False

            else:
                if self.is_camera_active:
                    print(f"[POWER RELAY] Score below threshold ({fusion_score:.2f}) -> Standby Mode.")
                    self.is_camera_active = False

            time.sleep(0.1)  # 100ms sample interval


# ==========================================
# 4. VSCODE EXECUTION & TESTING
# ==========================================
if __name__ == "__main__":
    engine = EdgeAIFusionEngine()

    # Start Edge Engine thread
    engine_thread = threading.Thread(target=engine.run, daemon=True)
    engine_thread.start()

    # Interactive CLI within VSCode Terminal to test real event triggers
    time.sleep(1)
    print("\n--- VSCODE TEST CONTROLLER ---")
    print("Press 'c' + Enter -> Simulate Vehicular Crash")
    print("Press 'k' + Enter -> Simulate Kidnapping Scream")
    print("Press 'q' + Enter -> Quit")

    while True:
        cmd = input().strip().lower()
        if cmd == 'c':
            print("\n[TEST] Injecting Crash Event Parameters...")
            engine.hardware.trigger_simulated_event("CRASH")
        elif cmd == 'k':
            print("\n[TEST] Injecting Kidnapping Scream Event Parameters...")
            engine.hardware.trigger_simulated_event("KIDNAPPING_SCREAM")
        elif cmd == 'q':
            engine.running = False
            break
