#!/usr/bin/env python3
"""Audio-triggered CCTV worker. Runs YOLO on the Pi and returns measured results."""

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any

import cv2
import websockets
from ultralytics import YOLO

HERE = Path(__file__).resolve().parent
PROJECT_DIR = HERE.parent
MODEL_PATH = Path(os.getenv("AURA_MODEL_PATH", str(PROJECT_DIR / "yolov8n.pt")))
DEFAULT_VIDEO = HERE / "crash.mp4"
VIDEO_SOURCE = os.getenv("AURA_VIDEO_SOURCE", str(DEFAULT_VIDEO))
GATEWAY_WS = os.getenv("AURA_GATEWAY_WS", "ws://127.0.0.1:5000/ws/edge")
NODE_ID = os.getenv("AURA_NODE_ID", "POLE-01")
INFERENCE_FPS = max(0.5, float(os.getenv("AURA_INFERENCE_FPS", "1")))
CAPTURE_SECONDS = max(1.0, float(os.getenv("AURA_CAPTURE_SECONDS", "8")))
IMAGE_SIZE = max(256, int(os.getenv("AURA_IMAGE_SIZE", "320")))
CONFIDENCE = min(0.95, max(0.05, float(os.getenv("AURA_DETECTION_CONFIDENCE", "0.30"))))


def configure_cpu() -> None:
    """Use CPU parallelism conservatively; keep headroom for streaming and the gateway."""
    cores = os.cpu_count() or 2
    threads = max(1, min(2, cores - 1))
    requested = os.getenv("AURA_CPU_THREADS")
    if requested:
        threads = max(1, min(cores, int(requested)))
    cv2.setNumThreads(threads)
    try:
        import torch

        torch.set_num_threads(threads)
        torch.set_num_interop_threads(1)
    except (ImportError, RuntimeError):
        pass
    print(f"[CPU] OpenCV/PyTorch worker threads: {threads} of {cores} cores")


def parse_video_source(value: str) -> str | int:
    value = value.strip()
    if value.isdecimal():
        return int(value)
    return value


def inspect_trigger(model: YOLO, trigger: dict[str, Any]) -> dict[str, Any]:
    source = parse_video_source(os.getenv("AURA_VIDEO_SOURCE", VIDEO_SOURCE))
    capture = cv2.VideoCapture(source)
    if not capture.isOpened():
        capture.release()
        raise RuntimeError(f"Cannot open video source: {source}")

    is_file = isinstance(source, str) and Path(source).is_file()
    source_fps = capture.get(cv2.CAP_PROP_FPS) or 25.0
    stride = max(1, round(source_fps / INFERENCE_FPS))
    frame_number = 0
    sampled_frames = 0
    max_vehicles = 0
    max_people = 0
    vehicle_confidences: list[float] = []
    started = time.monotonic()
    deadline = started + CAPTURE_SECONDS

    print(f"[VISION] Trigger {trigger.get('trigger_id')} -> {source}")
    try:
        while True:
            if not is_file and time.monotonic() >= deadline:
                break
            ok, frame = capture.read()
            if not ok or frame is None:
                break
            frame_number += 1
            if frame_number % stride:
                continue

            result = model.predict(
                frame,
                imgsz=IMAGE_SIZE,
                conf=CONFIDENCE,
                classes=[0, 2, 3, 5, 7],  # person, car, motorcycle, bus, truck
                max_det=20,
                device="cpu",
                verbose=False,
            )[0]
            sampled_frames += 1
            frame_vehicles = 0
            frame_people = 0
            if result.boxes is not None:
                for box in result.boxes:
                    class_id = int(box.cls[0].item())
                    label = str(model.names[class_id]).lower()
                    score = float(box.conf[0].item())
                    if label in {"car", "motorcycle", "bus", "truck"}:
                        frame_vehicles += 1
                        vehicle_confidences.append(score)
                    elif label == "person":
                        frame_people += 1
            max_vehicles = max(max_vehicles, frame_vehicles)
            max_people = max(max_people, frame_people)
    finally:
        capture.release()

    possible_incident = max_vehicles >= 2
    if possible_incident:
        visual_status = "POTENTIAL_INCIDENT_REQUIRES_REVIEW"
        event_type = "POTENTIAL_VEHICLE_INCIDENT"
        state = "NEEDS_HUMAN_VERIFICATION"
    else:
        visual_status = "NO_VISUAL_CONFIRMATION"
        event_type = "NO_VISUAL_CONFIRMATION"
        state = "NO_VISUAL_CONFIRMATION"

    details: dict[str, Any] = {
        "visual_status": visual_status,
        "max_vehicles_in_frame": max_vehicles,
        "max_pedestrians_in_frame": max_people,
        "sampled_frames": sampled_frames,
        "model": MODEL_PATH.name,
        "vehicle_detection_confidence_mean": round(sum(vehicle_confidences) / len(vehicle_confidences), 3)
        if vehicle_confidences
        else None,
        "heuristic": "two or more COCO vehicle detections in a sampled frame; this is a review cue, not proof of a collision",
    }
    return {
        "type": "EDGE_ALERT" if possible_incident else "VISION_RESULT",
        "data": {
            "node_id": str(trigger.get("node_id") or NODE_ID),
            "trigger_id": trigger.get("trigger_id"),
            "timestamp_ms": int(time.time() * 1000),
            "state": state,
            "anomaly_type": event_type,
            "visual_status": visual_status,
            "trigger_source": trigger.get("trigger_source", "audio"),
            "extracted_details": details,
            "stream_url": trigger.get("stream_url"),
        },
    }


async def serve() -> None:
    configure_cpu()
    print(f"[MODEL] Loading {MODEL_PATH}")
    model = YOLO(str(MODEL_PATH))
    backoff = 1
    while True:
        try:
            print(f"[EDGE] Connecting to {GATEWAY_WS}")
            async with websockets.connect(GATEWAY_WS, ping_interval=20, ping_timeout=20) as ws:
                print(f"[EDGE] Connected; waiting for audio triggers on node {NODE_ID}")
                backoff = 1
                async for raw in ws:
                    message = json.loads(raw)
                    if message.get("type") != "VISION_TRIGGER":
                        continue
                    trigger = message.get("data") or {}
                    try:
                        result = await asyncio.to_thread(inspect_trigger, model, trigger)
                    except Exception as exc:
                        result = {
                            "type": "VISION_RESULT",
                            "data": {
                                "node_id": str(trigger.get("node_id") or NODE_ID),
                                "trigger_id": trigger.get("trigger_id"),
                                "timestamp_ms": int(time.time() * 1000),
                                "state": "VISION_ERROR",
                                "anomaly_type": "VISION_PROCESSING_ERROR",
                                "visual_status": "VISION_PROCESSING_ERROR",
                                "error": str(exc),
                            },
                        }
                    await ws.send(json.dumps(result))
                    print(f"[VISION] {result['data']['visual_status']} | node={result['data']['node_id']}")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"[EDGE] Gateway unavailable ({exc}); retrying in {backoff}s")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30)


if __name__ == "__main__":
    asyncio.run(serve())
